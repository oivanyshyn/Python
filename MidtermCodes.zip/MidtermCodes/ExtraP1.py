import random 

cpu = ["rock","paper","scissors"]
keep_game="true"
player=''
pcount=0
pcount=int(pcount)
ccount=0
ccount=int(ccount)
while keep_game=="true":
            cpu_move=random.choice(cpu)
            print("------------------")
            print("...rock...\n...paper...\n...scissors...")
            player=input("(Enter your choice): ")
            print("The computer plays: ",cpu_move)
            if cpu_move==player:
                        print("It`s a tie!")
                        print(f"Player score: {pcount} Computer score: {ccount}")
            elif cpu_move== "rock"  and player== "scissors":
                        print("Computer win")
                        ccount += 1
                        if ccount==3:
                                    print("OH NO, COMPUTER WON")
                                    keep_game="false" 
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}")
            elif  cpu_move=="rock" and player=="paper":
                        print("Player win")
                        pcount += 1
                        if pcount==3:
                                    print("CONGRATZ, YOU WIN")
                                    keep_game="false" 
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}")         
            elif cpu_move=="paper" and player=="rock":
                        print("Computer win")
                        ccount += 1
                        if ccount==3:
                                    print("OH NO, COMPUTER WON")
                                    keep_game="false"
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}")        
            elif cpu_move=="paper" and player=="scissors":
                        print("Player win") 
                        pcount += 1
                        if pcount==3:
                                    print("CONGRATZ, YOU WIN")
                                    keep_game="false"
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}")
            elif cpu_move=="scissors" and player=="rock":
                        print("Player win")
                        pcount += 1
                        if pcount==3:
                                    print("CONGRATZ, YOU WIN")
                                    keep_game="false"   
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}")        
            elif cpu_move=="scissors:" and player=="paper":
                        print("Computer win")
                        ccount += 1
                        if ccount==3:
                                    print("OH NO, COMPUTER WON")
                                    keep_game="false"
                                    
                        print(f"Player score: {pcount} Computer score: {ccount}") 
            elif player=="q" or player =="quit":
                        keep_game="false"
        
            