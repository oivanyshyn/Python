x=input('Enter a number:')
x=int(x)
smallest = 9
while x>0:
    digit=x%10
    if digit<smallest:
        smallest=digit
    x=x/10
print(smallest)
    