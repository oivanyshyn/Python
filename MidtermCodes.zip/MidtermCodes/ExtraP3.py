x=int(input('Enter a number:'))
count=0
while x > 0:
   if x % 2 == 0:
      count +=1
      x = x / 2
      print(x)
      break
   elif x>1:
      x = 3 * x + 1 
      count +=1
      print(x)
   if x == 1:
      break
   
print(f'Intermediate numbers {x} were printed {count} times')