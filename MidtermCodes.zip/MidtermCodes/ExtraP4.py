import random

x=random.randint(1,10)
keep_game = "true"
while keep_game=="true":
    y=int(input('Pick a number from 1 to 10: '))
    if y==x:
        print('You won')
        k=input('Do you want to play again?(y/n): ')
        if k=="y":
            keep_game="true"
        else:
            keep_game="false"        
    elif y < x:
        print('Too low')
    else:
        print('Too high')
    
print('Thanks for playing')
      

            
            
        
    
    
    
    