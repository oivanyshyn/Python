n1 = int(input("Enter the Number: "))

while n1 > 10:
    sum = 0
    while n1 > 0:
        sum += (n1 % 10)
        number //= 10
    n1 = sum

print('Sum is ' + str(n))