x=input('Is Hamming number?(1 for Yes and 0 for No):')
x=int(x)

def is_hamming_numbers(x):
    if x == 1:
        return 1
    if x % 2 == 0:
        return is_hamming_numbers(x/2)
    if x % 3 == 0:
        return is_hamming_numbers(x/3)
    if x % 5 == 0:
        return is_hamming_numbers(x/5)
    return 0
print(is_hamming_numbers(x))