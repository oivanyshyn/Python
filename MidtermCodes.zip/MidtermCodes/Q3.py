x = input('Enter your percentage:')
x=int(x)
while x>=0 and x<100:
    if x >= 0 and x < 50:
        print("Your grade is F")
        break
    elif x>=50 and x<55:
        print("Your grade is D")
        break
    elif x>=55 and x<60:
        print("Your grade is D+")
        break
    elif x>=60 and x<65:
        print("Your grade is C")
        break
    elif x>=65 and x<70:
        print("Your grade is C+") 
        break
    elif x>=70 and x<75:
        print("Your grade is B")
        break
    elif x>=75 and x<80:
        print("Your grade is B+")
        break
    elif x>=80 and x<90:
        print("Your grade is A")
        break
    elif x>=90 and x<=100:
        print("Your grade is A+")
        break
    