flag=0
num=input('Enter a number:')
num=int(num)
temp=num
frequency = []
i=0
for i in range (0,10):
    frequency[i]=1
    while num > 0:
        k=num%10
        frequency[k]+1
        num=num/10
        for i in range (0,10):
            if frequency[i]>=1:
                flag=1
                print(f'{i} repeated {frequency[i]} times')
                if flag==0:
                    print('No Repeated Digits!')