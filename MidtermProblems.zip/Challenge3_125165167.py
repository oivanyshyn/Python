import hashlib

m = hashlib.sha256()
m.update(b"A 5 TB file")
print(m.digest())

m1 = hashlib.sha256()
m1.update(b"A 5 TB file")
print(m1.digest())

print(m1.digest() == m.digest())