import re

phonenumber= input("Enter a phone number with XXX-XXX-XXXX pattern, where X is a number")

regex= "\w{3}-\w{3}-\w{4}"
if re.search(regex, phonenumber):
    print("Valid phone number")
else:
    print("Invalid phone number")

