from simhash import simhash

def split_hash(str, num):
    return [ str[start:start+num] for start in range(0, len(str), num) ]

lashes = {}
for doc_id, doc in documents.items():
    hash = simhash(doc)

    hash_piece = split_hash(hash, 4)

    for piece in hash_piece:
        if piece not in lashes:
            lashes[piece] = []
        lashes[piece].append(doc_id)

for hash, doc_list in lashes:
    if doc_list > 1:
        print(doc_list)