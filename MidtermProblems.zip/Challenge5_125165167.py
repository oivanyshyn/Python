import requests
url = "https://icanhazdadjoke.com/search"
inp = input("Let me tell you a joke! Give me a topic: ")
inp = str(inp)
response = requests.get(
    url,
        headers={"Accept": "application/json"},
        params={"term": ""+inp, "limit": 1},
)

data = response.json()

num = data["total_jokes"]

if num == 0:
    print(f"Sorry, I don`t have any jokes about {inp}! Please try again.")
    print(data["results"])
elif num == 1:
    print(f"I`ve got one joke about {inp}. Here it is")
    print(data["results"])
else:
    print(f"I`ve got {num} jokes about {inp}. Here`s one")
    print(data["results"])