def palSubStrs(s): 
    m = dict() 
    n = len(s) 
  
    Rad = [[0 for x in range(n+1)] for x in range(2)] 
  
    s = "@" + s + "#"
  
    for j in range(2): 
        palr = 0   
        Rad[j][0] = 0
  
        i = 1
        while i <= n: 
 
            while s[i - palr - 1] == s[i + j + palr]: 
                palr += 1 
            Rad[j][i] = palr 
            k = 1
            while (Rad[j][i - k] != palr - k) and (k < palr): 
                Rad[j][i+k] = min(Rad[j][i-k], palr - k) 
                k += 1
            palr = max(palr - k, 0) 
            i += k 

    s = s[1:len(s)-1] 
  
    m[s[0]] = 1
    for i in range(1,n): 
        for j in range(2): 
            for palr in range(Rad[j][i],0,-1): 
                m[s[i - palr - 1 : i - palr - 1 + 2 * palr + j]] = 1
        m[s[i]] = 1
    for i in m: 
        print (i)

palSubStrs('aabbbaa')
